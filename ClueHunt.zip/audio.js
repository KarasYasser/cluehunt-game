/* ClueHunt — audio.js
 * Procedural mystery music + per-stage sound effects via Web Audio.
 * No audio files: everything is synthesized, so it works offline and
 * ships tiny. Music and SFX can be disabled independently (Settings);
 * preferences persist in localStorage.
 */
'use strict';

const AUDIO = (() => {
  const KEY = 'mb_audio';
  let prefs = { music: true, sfx: true };
  let ctx = null;
  let musicGain = null, sfxGain = null;
  let musicBuilt = false, musicTimer = null, noteTimer = null;
  let armed = false; /* first user gesture happened */

  try {
    const raw = localStorage.getItem(KEY);
    if (raw) prefs = Object.assign(prefs, JSON.parse(raw));
  } catch (e) { /* storage unavailable */ }

  function persist() {
    try { localStorage.setItem(KEY, JSON.stringify(prefs)); } catch (e) { /* noop */ }
  }

  function ensureCtx() {
    if (!ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
      musicGain = ctx.createGain(); musicGain.gain.value = prefs.music ? 1 : 0; musicGain.connect(ctx.destination);
      sfxGain = ctx.createGain(); sfxGain.gain.value = prefs.sfx ? 1 : 0; sfxGain.connect(ctx.destination);
    }
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    return ctx;
  }

  /* ---------- helpers ---------- */
  function env(node, t0, attack, peak, decay) {
    const g = node.gain;
    g.cancelScheduledValues(t0);
    g.setValueAtTime(0.0001, t0);
    g.exponentialRampToValueAtTime(peak, t0 + attack);
    g.exponentialRampToValueAtTime(0.0001, t0 + attack + decay);
  }
  function tone(freq, dur, type, vol, delay, dest, slideTo) {
    if (!ctx) return;
    const t0 = ctx.currentTime + (delay || 0);
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq, t0);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
    env(g, t0, 0.012, vol, dur);
    o.connect(g); g.connect(dest || sfxGain);
    o.start(t0); o.stop(t0 + dur + 0.08);
  }
  function noiseBurst(dur, vol, filterFreq, type) {
    if (!ctx) return;
    const t0 = ctx.currentTime;
    const len = Math.max(1, Math.floor(ctx.sampleRate * dur));
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = ctx.createBufferSource(); src.buffer = buf;
    const f = ctx.createBiquadFilter(); f.type = type || 'bandpass'; f.frequency.value = filterFreq || 1200; f.Q.value = 1.1;
    const g = ctx.createGain(); g.gain.value = vol;
    src.connect(f); f.connect(g); g.connect(sfxGain);
    src.start(t0);
  }

  /* ---------- music: dark drone + wandering pentatonic motif ---------- */
  const SCALE = [220.0, 261.63, 293.66, 349.23, 392.0, 440.0, 523.25]; /* A minor penta-ish */
  function buildMusic() {
    if (musicBuilt || !ctx) return;
    musicBuilt = true;

    /* low drone: two detuned sines */
    [55, 82.41, 82.9].forEach((f, i) => {
      const o = ctx.createOscillator();
      o.type = i === 0 ? 'sine' : 'triangle';
      o.frequency.value = f;
      const g = ctx.createGain();
      g.gain.value = i === 0 ? 0.16 : 0.06;
      /* slow breathing LFO */
      const lfo = ctx.createOscillator(); lfo.frequency.value = 0.05 + i * 0.017;
      const lfoG = ctx.createGain(); lfoG.gain.value = 0.045;
      lfo.connect(lfoG); lfoG.connect(g.gain);
      o.connect(g); g.connect(musicGain);
      o.start(); lfo.start();
    });

    /* airy noise pad */
    const len = ctx.sampleRate * 4;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    const src = ctx.createBufferSource(); src.buffer = buf; src.loop = true;
    const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 320;
    const ng = ctx.createGain(); ng.gain.value = 0.035;
    src.connect(lp); lp.connect(ng); ng.connect(musicGain);
    src.start();

    /* wandering mystery motif */
    function motif() {
      if (prefs.music && ctx && ctx.state !== 'closed') {
        const n = SCALE[Math.floor(Math.random() * SCALE.length)] * (Math.random() < 0.25 ? 0.5 : 1);
        const o = ctx.createOscillator(); o.type = 'triangle'; o.frequency.value = n;
        const g = ctx.createGain();
        const t0 = ctx.currentTime;
        env(g, t0, 0.05, 0.05, 1.9);
        /* simple echo */
        const dl = ctx.createDelay(); dl.delayTime.value = 0.42;
        const fb = ctx.createGain(); fb.gain.value = 0.34;
        o.connect(g); g.connect(musicGain); g.connect(dl); dl.connect(fb); fb.connect(dl); dl.connect(musicGain);
        o.start(t0); o.stop(t0 + 2.2);
      }
      noteTimer = setTimeout(motif, 3500 + Math.random() * 6000);
    }
    clearTimeout(noteTimer);
    noteTimer = setTimeout(motif, 2500);
    musicBuilt = true;
  }
  function startMusic() {
    if (!ensureCtx() || !prefs.music) return;
    buildMusic();
    if (musicGain) musicGain.gain.setTargetAtTime(1, ctx.currentTime, 0.6);
  }
  function stopMusic() {
    if (musicGain && ctx) musicGain.gain.setTargetAtTime(0, ctx.currentTime, 0.35);
  }

  /* ---------- public prefs ---------- */
  function musicEnabled() { return prefs.music; }
  function sfxEnabled() { return prefs.sfx; }
  function setMusic(on) {
    prefs.music = !!on; persist();
    if (prefs.music) startMusic(); else stopMusic();
  }
  function setSfx(on) { prefs.sfx = !!on; persist(); }
  function toggleMusic() { setMusic(!prefs.music); }
  function toggleSfx() { setSfx(!prefs.sfx); }

  /* ---------- SFX per stage ---------- */
  const SFX = {
    click:    () => noiseBurst(0.045, 0.10, 2400, 'highpass'),
    open:     () => { noiseBurst(0.22, 0.06, 620, 'lowpass'); tone(330, 0.28, 'sine', 0.05, 0.02, sfxGain, 440); },
    evidence: () => { tone(1318.5, 0.16, 'sine', 0.10); tone(1760, 0.22, 'sine', 0.075, 0.07); },
    suspect:  () => { noiseBurst(0.08, 0.07, 900, 'bandpass'); tone(196, 0.16, 'triangle', 0.06, 0.03); },
    hint:     () => { tone(659.25, 0.22, 'triangle', 0.09); tone(440, 0.34, 'triangle', 0.08, 0.16); },
    fail:     () => { tone(120, 0.42, 'sawtooth', 0.11, 0, sfxGain, 66); noiseBurst(0.18, 0.05, 300, 'lowpass'); },
    solve:    () => { [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => tone(f, 0.5, 'triangle', 0.10, i * 0.09)); noiseBurst(0.5, 0.05, 5200, 'highpass'); },
    achievement: () => { [880, 1174.66, 1567.98].forEach((f, i) => tone(f, 0.6, 'sine', 0.09, i * 0.11)); },
    buy:      () => { [784, 1046.5, 1318.5, 1568].forEach((f, i) => tone(f, 0.35, 'sine', 0.09, i * 0.06)); },
    streak:   () => { tone(659.25, 0.3, 'sine', 0.09); tone(987.77, 0.45, 'sine', 0.08, 0.14); },
    daily:    () => { tone(392, 0.3, 'triangle', 0.08); tone(523.25, 0.4, 'triangle', 0.07, 0.15); }
  };
  function play(name) {
    if (!prefs.sfx) return;
    if (!armed) return;               /* wait for a real user gesture */
    if (!ensureCtx()) return;
    const fn = SFX[name];
    if (fn) { try { fn(); } catch (e) { /* audio must never break the app */ } }
  }

  /* arm on first gesture (autoplay policy) + lazily start music */
  function arm() {
    if (armed) return;
    armed = true;
    if (prefs.music) startMusic();
  }
  ['pointerdown', 'keydown', 'touchend'].forEach(ev =>
    document.addEventListener(ev, arm, { once: true, passive: true })
  );

  /* pause when the app is hidden */
  document.addEventListener('visibilitychange', () => {
    if (!ctx) return;
    if (document.hidden) ctx.suspend().catch(() => {});
    else if (armed) ctx.resume().catch(() => {});
  });

  return { play, setMusic, setSfx, toggleMusic, toggleSfx, musicEnabled, sfxEnabled };
})();
