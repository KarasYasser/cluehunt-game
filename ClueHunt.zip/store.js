/* ClueHunt — store.js
 * Purchase adapter: Premium subscription $5.99/month + one-off packs.
 * On the web it uses a local sandbox (no real charge). In a native
 * Capacitor build it delegates to window.ClueHuntIAP, implemented by
 * the Google Play Billing / Apple StoreKit bridge (see BUILD_GUIDE.md).
 */
'use strict';

const STORE = (() => {
  const PRODUCTS = {
    premium_monthly: { id: 'premium_monthly', kind: 'subscription', price: '$5.99', per: 'month', title: 'ClueHunt Premium' },
    pack_starter:    { id: 'pack_starter',    kind: 'non_consumable', price: '$1.99', title: 'Starter Pack', detail: '5 bonus cases' },
    pack_detective:  { id: 'pack_detective',  kind: 'non_consumable', price: '$3.99', title: 'Detective Pack', detail: '10 bonus cases' },
    hints_10:        { id: 'hints_10',        kind: 'consumable',     price: '$0.99', title: '10 Hint Tokens' }
  };

  const DEFAULT = { premium: false, packs: [], hints: 0, tx: null, sandbox: false };
  let state = load();

  function load() {
    try {
      const raw = localStorage.getItem('mb_store');
      if (raw) return Object.assign({}, DEFAULT, JSON.parse(raw));
    } catch (e) { /* storage unavailable */ }
    return Object.assign({}, DEFAULT);
  }
  function save() {
    try { localStorage.setItem('mb_store', JSON.stringify(state)); } catch (e) { /* noop */ }
  }

  /* Native bridge present? (Capacitor build with IAP plugin) */
  function native() {
    return (typeof window !== 'undefined') && window.ClueHuntIAP &&
           typeof window.ClueHuntIAP.purchase === 'function';
  }

  /* Purchase a product. Resolves {ok, product, sandbox?, error?}. */
  async function purchase(productId) {
    const p = PRODUCTS[productId];
    if (!p) return { ok: false, error: 'unknown-product' };

    if (native()) {
      try {
        const res = await window.ClueHuntIAP.purchase(productId);
        if (res && res.ok) { apply(productId, res.transactionId, false); return { ok: true, product: p, tx: res.transactionId }; }
        return { ok: false, error: (res && res.error) || 'native-failed' };
      } catch (e) {
        return { ok: false, error: String(e && e.message || e) };
      }
    }

    /* Web sandbox: no real charge */
    apply(productId, 'sandbox-' + Date.now(), true);
    return { ok: true, product: p, sandbox: true };
  }

  function apply(productId, txId, sandbox) {
    const p = PRODUCTS[productId];
    if (p.kind === 'subscription') state.premium = true;
    else if (p.kind === 'non_consumable') { if (state.packs.indexOf(productId) === -1) state.packs.push(productId); }
    else if (p.kind === 'consumable') state.hints += 10;
    state.tx = { id: productId, tx: txId, at: Date.now(), sandbox: !!sandbox };
    save();
  }

  /* Restore previously purchased entitlements. */
  async function restore() {
    if (native() && typeof window.ClueHuntIAP.restore === 'function') {
      try {
        const res = await window.ClueHuntIAP.restore();
        if (res && Array.isArray(res.owned)) {
          state.premium = res.owned.indexOf('premium_monthly') !== -1;
          state.packs = res.owned.filter(id => id !== 'premium_monthly' && id !== 'hints_10');
          save();
          return { ok: true, count: res.owned.length };
        }
        return { ok: false, error: (res && res.error) || 'native-restore-failed' };
      } catch (e) {
        return { ok: false, error: String(e && e.message || e) };
      }
    }
    const had = state.premium || state.packs.length > 0;
    return { ok: true, count: had ? 1 : 0, sandbox: true };
  }

  function isPremium() { return !!state.premium; }
  function ownsPack(id) { return state.packs.indexOf(id) !== -1; }
  function hintCount() { return state.hints | 0; }
  function spendHint() { if (state.hints > 0) { state.hints--; save(); return true; } return false; }
  function product(id) { return PRODUCTS[id]; }
  function all() { return Object.keys(PRODUCTS).map(k => PRODUCTS[k]); }
  function price() { return PRODUCTS.premium_monthly.price; } /* "$5.99" */
  function reset() { state = Object.assign({}, DEFAULT); save(); }

  return { purchase, restore, isPremium, ownsPack, hintCount, spendHint, product, all, price, reset, native };
})();
