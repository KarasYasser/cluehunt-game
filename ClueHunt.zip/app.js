/* ClueHunt — app.js
 * Screens: Home, Cases, Details, Investigation, Daily, Multiplayer, Store, Archive, Settings.
 * Progress/XP/achievements live in localStorage; purchases in store.js; text in i18n.js.
 */
'use strict';

I18N.init();
const t = I18N.t;

/* ---------- progress ---------- */
const PROG_DEFAULT = {
  xp: 0, solved: {}, opened: {}, seen: {}, usedHints: {}, notes: {},
  ach: {}, daily: { date: null, id: null, attempts: 0, solved: false, streak: 0 }
};
let PROG = loadProg();

function loadProg() {
  try {
    const raw = localStorage.getItem('mb_progress');
    if (raw) return Object.assign({}, PROG_DEFAULT, JSON.parse(raw));
  } catch (e) { /* storage unavailable */ }
  return JSON.parse(JSON.stringify(PROG_DEFAULT));
}
function saveProg() {
  try { localStorage.setItem('mb_progress', JSON.stringify(PROG)); } catch (e) { /* noop */ }
}

/* ---------- app state ---------- */
const state = {
  screen: 'home',
  selected: null,
  tab: 'evidence',
  room: null,
  role: null,
  filters: { category: 'All', difficulty: 'All', length: 'All', type: 'All' }
};

/* ---------- case lookup: normal library + multiplayer campaign ---------- */
function findCase(id) {
  return CASES.find(x => x.id === id) || MP_CASES.find(x => x.id === id) || null;
}
function allCases() { return CASES.concat(MP_CASES); }
function isMultiplayer(c) { return !!c && c.mode === 'multiplayer'; }

/* ---------- helpers ---------- */
function esc(s) {
  return String(s == null ? '' : s)
    .split('&').join('&amp;').split('<').join('&lt;').split('>').join('&gt;')
    .split('"').join('&quot;').split("'").join('&#39;');
}
let toastTimer = null;
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
}
function today() { const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
function level() { return Math.floor(PROG.xp / 500) + 1; }
function solvedCount() { return Object.keys(PROG.solved).length; }
function isLocked(c) { return c.premium && !STORE.isPremium(); }
function dots(diff) {
  const n = diff === 'Easy' ? 1 : diff === 'Medium' ? 2 : diff === 'Hard' ? 3 : diff === 'Expert' ? 4 : 5;
  return '●'.repeat(n);
}
function diffLabel(c) { return t(c.difficulty.toLowerCase()); }
function lenLabel(c) { return t(c.length.toLowerCase()); }
function catName(cat) {
  const key = CATKEY[cat];
  const v = key ? t('cat_' + key) : cat;
  return v.indexOf('cat_') === 0 ? cat : v;
}
/* The brand guide asks for a different slogan at each stage of an
 * investigation, so the header line follows the player through the app. */
function slogan() {
  if (state.screen === 'investigation') {
    if (state.tab === 'suspects') return t('sloganSuspects');
    if (state.tab === 'evidence') return t('sloganEvidence');
    if (state.tab === 'notes') return t('sloganFinal');
    return t('sloganInvestigation');
  }
  if (state.screen === 'multi' && state.room && state.role === 'criminal') return t('sloganCriminal');
  if (state.screen === 'details' || state.screen === 'daily') return t('sloganInvestigation');
  if (state.screen === 'cases' || state.screen === 'archive') return t('sloganEvidence');
  if (state.screen === 'multi') return t('sloganInvestigation');
  return t('sloganHome');
}
function mysteryLine() { return t('mysteryLine' + (1 + Math.floor(Math.random() * 3))); }
let splashTimer = null;
function splash(text) {
  const el = document.getElementById('splash');
  if (!el) return;
  el.querySelector('.splash-line').textContent = text;
  el.querySelector('.splash-brand').textContent = t('sloganHome');
  el.classList.add('show');
  clearTimeout(splashTimer);
  splashTimer = setTimeout(() => el.classList.remove('show'), 1050);
}
const CATKEY = {
  'Fictional Mysteries': 'fiction', 'True Stories': 'true', 'Historical Mysteries': 'hist',
  'Unsolved Mysteries': 'unsolved', 'Missing Objects': 'missing', 'Impossible Rooms': 'impossible',
  'Hidden Identity': 'identity', 'Cyber Mysteries': 'cyber', 'Treasure Hunts': 'treasure',
  'Logic Mysteries': 'logic'
};

/* ---------- Mystery Themes (ClueHunt_Mystery_Themes.pdf) ----------
 * Every mystery category carries its own atmosphere — background, accent and
 * panel tint. The logo, navigation, typography and layout never change, per
 * the brand direction: CLUEHUNT stays recognizable, the mood shifts. */
const THEMES = {
  crime:      { key: 'crime',      name: 'Crime',        vio: '#ff5c7a', vio2: '#ff9db1', gold: '#ffd166', bg: '#0b0a0e', panel: '#1a1116' },
  logic:      { key: 'logic',      name: 'Logic',        vio: '#7c8cff', vio2: '#a9b4ff', gold: '#ffd166', bg: '#080b1a', panel: '#131a3a' },
  historical: { key: 'historical', name: 'Historical',   vio: '#b98a3c', vio2: '#e2b869', gold: '#ffd166', bg: '#0d0a06', panel: '#211910' },
  cyber:      { key: 'cyber',      name: 'Cyber',        vio: '#35d6e3', vio2: '#83f0f8', gold: '#35d6e3', bg: '#04090c', panel: '#0e1e23' },
  dark:       { key: 'dark',       name: 'Dark Mystery', vio: '#8e6cff', vio2: '#a88bff', gold: '#ffd166', bg: '#070914', panel: '#101426' },
  adventure:  { key: 'adventure',  name: 'Adventure',    vio: '#3fae74', vio2: '#7ddba5', gold: '#e8c34a', bg: '#050b08', panel: '#0e1e15' },
  theft:      { key: 'theft',      name: 'Theft',        vio: '#c8a44a', vio2: '#e8cd82', gold: '#ffd166', bg: '#0a0906', panel: '#1e1a0f' },
  secret:     { key: 'secret',     name: 'Secret Files', vio: '#8fa2c8', vio2: '#c6d1e6', gold: '#cfd8ea', bg: '#070a12', panel: '#121a2c' }
};
const CATEGORY_THEME = {
  'Fictional Mysteries': 'crime', 'True Stories': 'crime',
  'Logic Mysteries': 'logic', 'Historical Mysteries': 'historical',
  'Cyber Mysteries': 'cyber', 'Unsolved Mysteries': 'dark',
  'Impossible Rooms': 'dark', 'Adventure': 'adventure',
  'Treasure Hunts': 'adventure', 'Missing Objects': 'theft',
  'Hidden Identity': 'secret'
};
function themeFor(cat) { return THEMES[CATEGORY_THEME[cat]] || THEMES.dark; }
function activeTheme() {
  if (state.selected && (state.screen === 'details' || state.screen === 'investigation')) {
    return themeFor(state.selected.category);
  }
  if (state.screen === 'cases' && state.filters.category !== 'All') return themeFor(state.filters.category);
  return THEMES.dark;
}
function applyTheme(th) {
  const root = document.documentElement;
  if (root.getAttribute('data-theme') === th.key) return;
  root.setAttribute('data-theme', th.key);
  const s = root.style;
  s.setProperty('--vio', th.vio);
  s.setProperty('--vio2', th.vio2);
  s.setProperty('--gold', th.gold);
  s.setProperty('--tmbg', th.bg);
  s.setProperty('--tmpanel', th.panel);
  s.setProperty('--tmglow', th.vio + '26');
  /* set the wash directly as well: the page background must change even where
     a platform paints its own canvas colour behind the app shell */
  document.body.style.backgroundColor = th.bg;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', th.bg);
}
function themeTag(c) {
  const th = themeFor(c.category);
  return `<span class="tag theme" style="border-color:${th.vio}66;color:${th.vio2}">● ${esc(th.name)}</span>`;
}

/* ---------- routing ---------- */
function go(s) { state.screen = s; state.tab = 'evidence'; AUDIO.play('open'); render(); window.scrollTo({ top: 0 }); }
function navBtn(id, icon, label) {
  return `<button class="${state.screen === id ? 'active' : ''}" onclick="go('${id}')"><span class="ic">${icon}</span>${esc(label)}</button>`;
}
function render() {
  applyTheme(activeTheme());
  document.getElementById('app').innerHTML = `
  <div class="app">
    <header class="top">
      <div>
        <div class="logo">CLUE<span>HUNT</span></div>
        <div class="tagline">${esc(slogan())}</div>
      </div>
      <div class="top-right">
        <button class="chip-btn" onclick="go('settings')" aria-label="${esc(t('language'))}">🌐 ${esc(I18N.meta().flag)} ${esc(I18N.meta().name)}</button>
        <button class="chip-btn ${STORE.isPremium() ? 'pro' : ''}" onclick="go('store')">${STORE.isPremium() ? '★ ' + esc(t('premiumBadge')) : '◆ ' + esc(t('navPremium'))}</button>
      </div>
    </header>
    <main class="content">${screen()}</main>
    <nav class="nav">
      ${navBtn('home', '⌂', t('navHome'))}
      ${navBtn('cases', '🔎', t('navCases'))}
      ${navBtn('daily', '📅', t('navDaily'))}
      ${navBtn('multi', '🎭', t('multiplayer'))}
      ${navBtn('store', '🛍️', t('store'))}
      ${navBtn('archive', '🗃️', t('archive'))}
      ${navBtn('settings', '⚙️', t('settings'))}
    </nav>
  </div>`;
}
function screen() {
  switch (state.screen) {
    case 'cases': return casesScreen();
    case 'details': return detailsScreen();
    case 'investigation': return investigationScreen();
    case 'daily': return dailyScreen();
    case 'multi': return multiScreen();
    case 'store': return storeScreen();
    case 'archive': return archiveScreen();
    case 'settings': return settingsScreen();
    default: return homeScreen();
  }
}

/* ---------- card partials ---------- */
function caseCard(c) {
  const locked = isLocked(c);
  const done = !!PROG.solved[c.id];
  return `<article class="card ${c.premium ? 'premium' : ''}">
    <div class="meta-row">
      <span class="tag diff">${dots(c.difficulty)} ${esc(diffLabel(c))}</span>
      <span class="tag ${c.length === 'Short' ? 'short' : 'long'}">${esc(lenLabel(c))}</span>
      ${c.type === 'True Story' ? `<span class="tag true">${esc(t('typeTrueBadge'))}</span>` : ''}
      ${c.premium ? `<span class="tag pro">${esc(t('premiumBadge'))}</span>` : `<span class="tag free">${esc(t('freeCase'))}</span>`}
      ${done ? `<span class="tag free">✓ ${esc(t('solved'))}</span>` : ''}
    </div>
    <h3>${esc(c.title)}</h3>
    <p class="meta">${esc(catName(c.category))} · ${esc(c.time)} · ${c.xp} ${esc(t('xp'))}</p>
    <p>${esc(c.summary)}</p>
    <p class="meta">${c.suspects} ${esc(t('suspects').toLowerCase())} · ${c.evidence} ${esc(t('evidence').toLowerCase())}</p>
    <button class="btn ${locked ? 'pro' : done ? 'secondary' : ''}" onclick="openCase('${c.id}')">
      ${locked ? esc(t('unlock')) : done ? esc(t('seeSolution')) : esc(t('play'))}
    </button>
  </article>`;
}
function cardGrid(list) {
  if (!list.length) return `<div class="notice">${esc(t('noResults'))} <button class="chip" onclick="resetFilters()">${esc(t('resetFilters'))}</button></div>`;
  return `<div class="grid">${list.map(caseCard).join('')}</div>`;
}

/* ---------- home ---------- */
function homeScreen() {
  const freeCases = CASES.filter(c => !c.premium);
  const featured = CASES.find(c => c.id === 'case001');
  const quick = CASES.filter(c => c.difficulty === 'Easy' && c.length === 'Short').slice(0, 4);
  const longs = CASES.filter(c => c.length === 'Long' && !c.premium).slice(0, 4);
  const continueList = allCases().filter(c => PROG.opened[c.id] && !PROG.solved[c.id]).slice(0, 4);
  const d = dailyCase();
  const premiumBanner = STORE.isPremium() ? '' : `
    <div class="notice pro">★ ${esc(t('premiumTitle'))} — ${esc(I18N.PRICE)}${esc(t('perMonth'))}. ${esc(t('premiumDesc'))}
      <div class="btn-row"><button class="btn pro" onclick="go('store')">${esc(t('goPremium'))}</button></div>
    </div>`;
  return `
  <section class="hero hero-brand">
    <img class="hero-mark" src="brand/logo-192.png" alt="ClueHunt" width="192" height="192">
    <span class="eyebrow">${esc(t('sloganHome'))}</span>
    <h1>${t('heroTitle')}</h1>
    <p>${esc(t('heroSub'))}</p>
    <div class="btn-row">
      <button class="btn" onclick="go('cases')">${esc(t('heroCta'))} →</button>
      <button class="btn secondary" onclick="go('daily')">📅 ${esc(t('dailyMystery'))}</button>
    </div>
    <p class="meta" style="margin-top:14px">${CASES.length} ${esc(t('casesAvailable'))} · ${freeCases.length} ${esc(t('freeCase'))} · ${MP_CASES.length} ${esc(t('mpLibrary'))} · ${esc(t('level'))} ${level()} · ${PROG.xp} ${esc(t('xp'))}</p>
  </section>
  ${premiumBanner}
  ${continueList.length ? `<h2>${esc(t('sectionContinue'))}</h2>${cardGrid(continueList)}` : ''}
  <h2>📅 ${esc(t('dailyMystery'))} <span class="count">${esc(t('streak'))}: ${PROG.daily.streak}</span></h2>
  ${cardGrid([d])}
  <h2>⚡ ${esc(t('sectionQuick'))}</h2>${cardGrid(quick)}
  <h2>🕰 ${esc(t('sectionLong'))}</h2>${cardGrid(longs)}
  <h2>🎭 ${esc(t('mpLibrary'))} <span class="count">${MP_CASES.length}</span></h2>
  <section class="hero">
    <span class="eyebrow">${esc(t('mpLibrarySub'))}</span>
    <p class="muted">${esc(t('mpShareNote'))}</p>
    <div class="btn-row"><button class="btn secondary" onclick="go('multi')">${esc(t('multiplayer'))} →</button></div>
  </section>
  <h2>📖 ${esc(t('howToPlay'))}</h2>
  <div class="panel-card">
    <p class="muted">1. ${esc(t('howTo1'))}</p>
    <p class="muted">2. ${esc(t('howTo2'))}</p>
    <p class="muted">3. ${esc(t('howTo3'))}</p>
    <p class="muted">4. ${esc(t('howTo4'))}</p>
  </div>`;
}

/* ---------- cases library with filters ---------- */
function resetFilters() { state.filters = { category: 'All', difficulty: 'All', length: 'All', type: 'All' }; render(); }
function setFilter(key, val) { state.filters[key] = val; AUDIO.play('click'); render(); }
function filteredCases() {
  const f = state.filters;
  return CASES.filter(c =>
    (f.category === 'All' || c.category === f.category) &&
    (f.difficulty === 'All' || c.difficulty === f.difficulty) &&
    (f.length === 'All' || c.length === f.length) &&
    (f.type === 'All' ||
      (f.type === 'True Story' ? c.type === 'True Story' : c.type !== 'True Story'))
  );
}
function chips(key, options, labels) {
  return options.map((o, i) =>
    `<button class="chip ${state.filters[key] === o ? 'active' : ''}" onclick="setFilter('${key}','${o.replace(/'/g, "\\'")}')">${esc(labels ? labels[i] : o)}</button>`
  ).join('');
}
function casesScreen() {
  const list = filteredCases();
  return `
  <h1>${t('navCases')} <span class="count">${list.length} / ${CASES.length} ${esc(t('results'))}</span></h1>
  <div class="filters">
    <div class="filter-line"><span class="lbl">${esc(t('fCategory'))}</span>
      ${chips('category', ['All'].concat(CATEGORIES), [t('all')].concat(CATEGORIES.map(catName)))}
    </div>
    <div class="filter-line"><span class="lbl">${esc(t('fDifficulty'))}</span>
      ${(() => {
        const used = DIFFICULTIES.filter(d => CASES.some(c => c.difficulty === d));
        return chips('difficulty', ['All'].concat(used), [t('all')].concat(used.map(d => t(d.toLowerCase()))));
      })()}
    </div>
    <div class="filter-line"><span class="lbl">${esc(t('fLength'))}</span>
      ${chips('length', ['All'].concat(LENGTHS), [t('all'), t('short'), t('long')])}
    </div>
    <div class="filter-line"><span class="lbl">${esc(t('fType'))}</span>
      ${chips('type', ['All', 'Fiction', 'True Story'], [t('typeAll'), t('typeFiction'), t('typeTrue')])}
    </div>
  </div>
  ${cardGrid(list)}`;
}

/* ---------- case details ---------- */
function openCase(id) {
  const c = findCase(id);
  if (!c) return;
  state.mpSeen = {};
  AUDIO.play('click');
  if (isLocked(c)) {
    state.selected = c;
    state.screen = 'details';
    render();
    return;
  }
  state.selected = c;
  state.screen = 'details';
  render();
}
function detailsScreen() {
  const c = state.selected;
  if (!c) { state.screen = 'cases'; return casesScreen(); }
  const locked = isLocked(c);
  const done = PROG.solved[c.id];
  const isTrue = c.type === 'True Story';
  return `
  <button class="btn secondary" onclick="go('cases')">← ${esc(t('back'))}</button>
  <section class="hero" style="margin-top:14px">
    <div class="meta-row">
      <span class="tag diff">${dots(c.difficulty)} ${esc(diffLabel(c))}</span>
      <span class="tag ${c.length === 'Short' ? 'short' : 'long'}">${esc(lenLabel(c))}</span>
      ${isTrue ? `<span class="tag true">${esc(t('typeTrueBadge'))}</span>` : ''}
      ${themeTag(c)}
      ${c.premium ? `<span class="tag pro">${esc(t('premiumBadge'))}</span>` : `<span class="tag free">${esc(t('freeCase'))}</span>`}
    </div>
    <h1>${esc(c.title)}</h1>
    <p>${esc(c.summary)}</p>
    <p class="meta">${esc(catName(c.category))} · ${esc(c.type)} · ${esc(c.time)} · ${c.suspects} ${esc(t('suspects').toLowerCase())} · ${c.evidence} ${esc(t('evidence').toLowerCase())} · ${c.xp} ${esc(t('xp'))}</p>
    ${locked ? `
      <div class="lock-note">🔒 ${esc(t('premiumCasesLocked'))}</div>
      <div class="btn-row"><button class="btn pro" onclick="go('store')">${esc(t('subscribeNow'))} — ${esc(I18N.PRICE)}${esc(t('perMonth'))}</button>
      <button class="btn ghost" onclick="go('cases')">${esc(t('maybeLater'))}</button></div>`
    : `<div class="btn-row">
        <button class="btn" onclick="startCase()">${done ? esc(t('continueCase')) : esc(t('startCase'))} →</button>
        ${done ? `<button class="btn secondary" onclick="startCase();setTimeout(()=>openSolution(),350)">${esc(t('seeSolution'))}</button>` : ''}
      </div>`}
    ${isTrue ? trueStoryBlock(c) : ''}
  </section>`;
}
function trueStoryBlock(c) {
  return `<div class="panel-card" style="margin-top:14px">
    ${c.facts ? `<div class="meta-row" style="margin-bottom:8px"><span class="tag true">${esc(t('fact'))}</span></div>
      <ul class="muted" style="padding-left:18px;margin:0">${c.facts.map(f => `<li>${esc(f)}</li>`).join('')}</ul>` : ''}
    ${c.theories ? `<div class="meta-row" style="margin:14px 0 8px"><span class="tag">${esc(t('theory'))}</span></div>
      <ul class="muted" style="padding-left:18px;margin:0">${c.theories.map(f => `<li>${esc(f)}</li>`).join('')}</ul>` : ''}
    ${c.sources ? `<div class="sep"></div><p class="small dim">${esc(t('sources'))}: ${c.sources.map(esc).join(' · ')}</p>` : ''}
  </div>`;
}

/* ---------- investigation ---------- */
function startCase() {
  const c = state.selected;
  if (!c || isLocked(c)) return;
  PROG.opened[c.id] = true;
  saveProg();
  state.screen = 'investigation';
  state.tab = 'evidence';
  splash(mysteryLine());   /* brand guide: rotating line on the transition in */
  render();
}
/* Multiplayer hot-seat: a player's clue stays hidden until they reveal it. */
function mpReveal(i) {
  state.mpSeen = state.mpSeen || {};
  if (state.mpSeen[i]) return;
  state.mpSeen[i] = true;
  AUDIO.play('evidence');
  render();
}
function setTab(tb) { state.tab = tb; AUDIO.play('click'); render(); }
/* Multiplayer roster: four players, four private clues. Each clue stays masked
 * until that player reveals it, so a shared screen cannot spoil the round. */
function mpRoster(c) {
  state.mpSeen = state.mpSeen || {};
  return `<div class="panel-card">
    <p class="small dim" style="margin:0 0 10px">${esc(t('mpShareNote'))}</p>
    ${MP_PLAYERS.map((who, i) => {
      const clue = c.evidenceItems[i];
      if (clue === undefined) return '';
      const shown = !!state.mpSeen[i];
      return `<div class="suspect">
        <div class="who"><b>${esc(t('mpPlayer'))} ${who}</b><span class="role">${esc(t('mpClues'))}</span></div>
        ${shown
          ? `<blockquote>“${esc(clue)}”</blockquote>`
          : `<blockquote class="muted">•••••••</blockquote>
             <div class="btn-row"><button class="btn ghost" onclick="mpReveal(${i})">🔓 ${esc(t('revealClue'))}</button></div>`}
      </div>`;
    }).join('')}
  </div>`;
}
function evidenceSeen(c) { return PROG.seen[c.id] || []; }
function examine(i) {
  const c = state.selected;
  const arr = evidenceSeen(c).slice();
  if (arr.indexOf(i) === -1) {
    arr.push(i);
    PROG.seen[c.id] = arr;
    saveProg();
    checkAchievements();
  }
  const item = c.evidenceItems[i];
  render();
  AUDIO.play('evidence');
  document.getElementById('modal').classList.add('open');
  document.getElementById('panel').innerHTML = `
    <button class="close" onclick="closeModal()">✕</button>
    <div class="eyebrow">${isMultiplayer(c) ? esc(t('mpPlayer')) + ' ' + MP_PLAYERS[i % MP_PLAYERS.length] + ' — ' + esc(t('mpClues')) : esc(t('evidence')) + ' ' + (i + 1) + ' / ' + c.evidence}</div>
    <h2 style="margin-top:8px">🔎 ${esc(isMultiplayer(c) ? t('mpClues') : t('evidence'))}</h2>
    <div class="panel-card" style="font-size:16px">${esc(item)}</div>
    <p class="small dim">${esc(t('progressLabel'))}: ${evidenceSeen(c).length}/${c.evidence}</p>`;
}
function closeModal() { document.getElementById('modal').classList.remove('open'); }

function hintsUsed(c) { return PROG.usedHints[c.id] || 0; }
function useHint() {
  const c = state.selected;
  const used = hintsUsed(c);
  if (used >= c.hints.length) {
    if (STORE.hintCount() > 0 && STORE.spendHint()) {
      PROG.usedHints[c.id] = used + 1;
      saveProg();
      AUDIO.play('hint');
      toast('+' + t('hint') + ': ' + t('extraHint'));
      render();
      return;
    }
    toast(t('noHintLeft'));
    return;
  }
  PROG.usedHints[c.id] = used + 1;
  saveProg();
  AUDIO.play('hint');
  render();
}
function notesArea(c) {
  const used = hintsUsed(c);
  const hintBlocks = c.hints.slice(0, used).map((h, i) =>
    `<div class="hint-box"><b>${esc(t('hint'))} ${i + 1} — ${esc(t(['hint1', 'hint2', 'hint3'][i]))}</b><br>${esc(h)}</div>`
  ).join('');
  const extra = used > c.hints.length
    ? `<div class="hint-box"><b>${esc(t('hint'))} ${c.hints.length + 1}</b><br>${esc(t('extraHint'))}</div>` : '';
  return `
  <div class="panel-card">
    <div class="meta-row"><span class="tag">${esc(t('hints'))}: ${used}/${c.hints.length}</span>
    ${STORE.hintCount() > 0 ? `<span class="tag xp">${esc(t('hint'))} ${esc(t('store'))}: ${STORE.hintCount()}</span>` : ''}</div>
    ${hintBlocks}${extra}
    <div class="btn-row"><button class="btn secondary" onclick="useHint()">💡 ${esc(t('hintUse'))}</button></div>
    <label class="small dim" for="notes">${esc(t('notes'))}</label>
    <textarea class="answer" id="notes" rows="4" placeholder="${esc(t('notes'))}…" oninput="saveNotes(this.value)">${esc(PROG.notes[c.id] || '')}</textarea>
  </div>`;
}
let notesTimer = null;
function saveNotes(v) {
  const c = state.selected;
  if (!c) return;
  PROG.notes[c.id] = v;
  clearTimeout(notesTimer);
  notesTimer = setTimeout(saveProg, 400);
}

function investigationScreen() {
  const c = state.selected;
  if (!c) { state.screen = 'cases'; return casesScreen(); }
  if (isLocked(c)) { state.screen = 'details'; return detailsScreen(); }
  const seen = evidenceSeen(c).length;
  const pct = Math.round((seen / c.evidence) * 100);
  const done = PROG.solved[c.id];
  const tabBtn = (id, label) => `<button class="tab ${state.tab === id ? 'active' : ''}" onclick="setTab('${id}')">${esc(label)}</button>`;
  const mp = isMultiplayer(c);
  let body = '';
  if (state.tab === 'evidence') {
    body = `<div class="panel-card">
      ${mp ? `<p class="small dim" style="margin:0 0 10px">${esc(t('mpShareNote'))}</p>` : ''}
      ${c.evidenceItems.map((e, i) => {
        const seen = evidenceSeen(c).indexOf(i) !== -1;
        const label = mp ? esc(t('mpPlayer')) + ' ' + MP_PLAYERS[i % MP_PLAYERS.length] : esc(t('evidence')) + ' ' + (i + 1);
        return `
        <div class="evidence-item ${seen ? 'seen' : ''}" onclick="examine(${i})" role="button" tabindex="0">
          <span class="ico">${seen ? '🔓' : '🔒'}</span>
          <span><b>${label}</b><span>${seen ? esc(e) : '••••••'}</span></span>
          ${seen ? `<span class="seal">✓</span>` : ''}
        </div>`;
      }).join('')}
    </div>`;
  } else if (state.tab === 'suspects') {
    body = mp ? mpRoster(c) : `<div class="panel-card">
      ${c.suspectsList.length ? c.suspectsList.map(s => `
        <div class="suspect">
          <div class="who"><b>${esc(s.name)}</b><span class="role">${esc(s.role)}</span></div>
          <blockquote>“${esc(s.statement)}”</blockquote>
        </div>`).join('') : `<p class="muted">${esc(t('noSuspects'))}</p>`}
    </div>`;
  } else if (state.tab === 'story') {
    body = `<div class="panel-card">
      <p style="font-size:16px">${esc(c.summary)}</p>
      <p class="muted">${esc(catName(c.category))} · ${esc(c.time)} · ${dots(c.difficulty)} ${esc(diffLabel(c))} · ${esc(lenLabel(c))}</p>
      ${c.type === 'True Story' ? trueStoryBlock(c) : ''}
    </div>`;
  } else {
    body = notesArea(c);
  }
  return `
  <div class="case-head">
    <div>
      <div class="meta-row">
        <span class="tag diff">${dots(c.difficulty)} ${esc(diffLabel(c))}</span>
        <span class="tag ${c.length === 'Short' ? 'short' : 'long'}">${esc(lenLabel(c))}</span>
        <span class="tag xp">${c.xp} ${esc(t('xp'))}</span>
        ${themeTag(c)}
        ${done ? `<span class="tag free">✓ ${esc(t('caseSolved'))}</span>` : ''}
      </div>
      <h1 style="margin:8px 0 0">${esc(c.title)}</h1>
    </div>
    <button class="btn secondary" onclick="go('cases')">← ${esc(t('back'))}</button>
  </div>
  <div class="progress" aria-label="${esc(t('progressLabel'))}"><i style="width:${pct}%"></i></div>
  <p class="small dim">${esc(t('evidenceFound'))}: ${seen}/${c.evidence} (${pct}%) · ${esc(t('hints'))}: ${hintsUsed(c)}</p>
  <div class="tabs">
    ${tabBtn('evidence', (isMultiplayer(c) ? '🔎 ' + t('mpClues') : '🔎 ' + t('evidence')))}
    ${tabBtn('suspects', '🎭 ' + (isMultiplayer(c) ? t('players') : t('suspects')))}
    ${tabBtn('story', '📖 ' + t('story'))}
    ${tabBtn('notes', '📝 ' + t('notes'))}
  </div>
  ${body}
  <div class="panel-card">
    <div class="eyebrow">${esc(t('yourDeduction'))}</div>
    ${done ? `<div class="result good"><b>${esc(t('caseSolved'))} ✓</b><br>${esc(t('xpAwarded'))}: +${PROG.solved[c.id].score} ${esc(t('xp'))}</div>` : `
      <textarea class="answer" id="deduction" rows="3" placeholder="${esc(t('deductionPlaceholder'))}"></textarea>
      <div id="deduction-result"></div>
      <div class="btn-row"><button class="btn" onclick="submitDeduction()">⚖️ ${esc(t('submitDeduction'))}</button></div>`}
    ${done ? `<div class="btn-row">
      <button class="btn secondary" onclick="openSolution()">${esc(t('seeSolution'))}</button>
      <button class="btn" onclick="nextCase()">${esc(t('nextCase'))} →</button>
    </div>` : ''}
  </div>`;
}

/* ---------- deduction scoring ---------- */
function contentWords(s) {
  const stop = new Set(('the a an of and or to in on at for with is was were be by that this it its from as not no but if then than who what when where how all any one two had has have do does did been being he she they we you i his her their our your my me him them us about into over under after before between through ' +
    'case room door key time night day hours minute minutes fact facts theory theories unknown unsolved').split(' '));
  return (s.toLowerCase().match(/[a-zà-ÿ0-9']{4,}/g) || [])
    .filter(w => !stop.has(w));
}
function answerScore(c, text) {
  const input = ' ' + text.toLowerCase().replace(/[^a-zà-ÿ0-9' ]/g, ' ') + ' ';
  const culpritTokens = (c.solution.culprit.toLowerCase().match(/[a-zà-ÿ0-9']{4,}/g) || [])
    .filter(w => !/unknown|n\/a|logic|puzzle|staged|none|unsolved|mystery|historical|reconstruction|itself|documented|found|open|never/i.test(w));
  const explWords = Array.from(new Set(contentWords(c.solution.explanation)));
  let hits = culpritTokens.filter(w => input.indexOf(' ' + w) !== -1).length;
  let wordHits = explWords.filter(w => input.indexOf(' ' + w) !== -1).length;
  return { culpritHits: hits, wordHits: wordHits, total: hits + wordHits };
}
function submitDeduction() {
  const c = state.selected;
  const el = document.getElementById('deduction');
  if (!el) return;
  const text = (el.value || '').trim();
  const box = document.getElementById('deduction-result');
  if (text.length < 4) {
    box.innerHTML = `<div class="result bad">${esc(t('deductionMiss'))}</div>`;
    return;
  }
  const s = answerScore(c, text);
  const need = c.solution.culprit.indexOf('N/A') === 0 || c.solution.culprit.indexOf('Unknown') === 0 ? 4 : 3;
  if (s.total >= need) {
    solveCase(c);
  } else {
    if (dailyCase().id === c.id) dailyAttempt();
    AUDIO.play('fail');
    box.innerHTML = `<div class="result bad">${esc(t('deductionMiss'))}</div>
      <p class="small dim">${esc(t('keepInvestigating'))} — ${esc(t('evidenceFound'))}: ${evidenceSeen(c).length}/${c.evidence}</p>`;
  }
}
function solveCase(c) {
  const used = hintsUsed(c);
  const seen = evidenceSeen(c).length;
  let score = c.xp - used * 40;
  if (used === 0) score += 100;                 /* no-hint bonus */
  if (seen === c.evidence) score += 50;         /* all-evidence bonus */
  if (score < 50) score = 50;
  PROG.solved[c.id] = { score: score, hints: used, at: Date.now(), perfect: used === 0 && seen === c.evidence };
  PROG.xp += score;
  /* daily bookkeeping */
  if (PROG.daily.date === today() && PROG.daily.id === c.id && !PROG.daily.solved) {
    PROG.daily.solved = true;
    PROG.daily.streak += 1;
    PROG.xp += 100;
    score += 100;
    AUDIO.play('streak');
  }
  saveProg();
  checkAchievements();
  render();
  AUDIO.play('solve');
  showSolved(c, score, used, seen);
}
function stars(used) {
  const n = used === 0 ? 5 : used === 1 ? 4 : used === 2 ? 3 : 2;
  return '★'.repeat(n) + '<span style="opacity:.25">' + '★'.repeat(5 - n) + '</span>';
}
function showSolved(c, score, used, seen) {
  document.getElementById('modal').classList.add('open');
  document.getElementById('panel').innerHTML = `
    <button class="close" onclick="closeModal()">✕</button>
    <div class="center">
      <div class="eyebrow">🔒 ${esc(t('caseSolved'))} — ${esc(t('sloganResults'))}</div>
      <h2>${esc(c.title)}</h2>
      <div style="font-size:26px;color:var(--gold);letter-spacing:4px">${stars(used)}</div>
      <div class="stats-grid" style="margin-top:16px">
        <div class="stat"><b>+${score}</b><span>${esc(t('xp'))}</span></div>
        <div class="stat"><b>${Math.round(seen / c.evidence * 100)}%</b><span>${esc(t('evidenceFound'))}</span></div>
        <div class="stat"><b>${used}</b><span>${esc(t('hints'))}</span></div>
        <div class="stat"><b>${level()}</b><span>${esc(t('level'))}</span></div>
      </div>
      <div class="btn-row" style="justify-content:center">
        <button class="btn secondary" onclick="openSolution()">${esc(t('seeSolution'))}</button>
        <button class="btn" onclick="closeModal();nextCase()">${esc(t('nextCase'))} →</button>
      </div>
    </div>`;
}
function openSolution() {
  const c = state.selected;
  document.getElementById('modal').classList.add('open');
  document.getElementById('panel').innerHTML = `
    <button class="close" onclick="closeModal()">✕</button>
    <div class="eyebrow">${esc(t('solution'))}</div>
    <h2 style="margin-top:8px">${esc(c.title)}</h2>
    <div class="result good"><b>${esc(t('solution'))}:</b> ${esc(c.solution.culprit)}</div>
    <div class="panel-card" style="margin-top:10px">${esc(c.solution.explanation)}</div>
    ${c.twist ? `<div class="eyebrow" style="margin-top:14px">${esc(t('twist'))}</div>
      <div class="panel-card" style="margin-top:6px">${esc(c.twist)}</div>` : ''}
    ${c.sources ? `<p class="small dim">${esc(t('sources'))}: ${c.sources.map(esc).join(' · ')}</p>` : ''}
    <div class="btn-row"><button class="btn" onclick="closeModal();nextCase()">${esc(t('nextCase'))} →</button></div>`;
}
function nextCase() {
  const src = isMultiplayer(state.selected) ? MP_CASES : CASES;
  const pool = src.filter(c => !isLocked(c) && !PROG.solved[c.id]);
  const pick = pool.length ? pool[Math.floor(Math.random() * pool.length)] : src[Math.floor(Math.random() * src.length)];
  openCase(pick.id);
}

/* ---------- daily mystery ---------- */
function dailyCase() {
  const seed = Math.floor(Date.now() / 86400000);
  const pool = CASES.filter(c => !c.premium || STORE.isPremium());
  return pool[seed % pool.length];
}
function dailyScreen() {
  const d = dailyCase();
  const doneToday = PROG.daily.date === today();
  const attemptsLeft = Math.max(0, 3 - (doneToday ? PROG.daily.attempts : 0));
  return `
  <h1>📅 ${esc(t('dailyMystery'))}</h1>
  <div class="stats-grid" style="margin-bottom:14px">
    <div class="stat"><b>${PROG.daily.streak}</b><span>${esc(t('streak'))}</span></div>
    <div class="stat"><b>${doneToday ? (PROG.daily.solved ? '✓' : '✗') : attemptsLeft}</b><span>${doneToday ? esc(t('solved')) : esc(t('attemptsLeft'))}</span></div>
    <div class="stat"><b>${solvedCount()}</b><span>${esc(t('casesSolved'))}</span></div>
  </div>
  ${doneToday && PROG.daily.solved ? `<div class="notice">${esc(t('dailyDone'))}</div>` : ''}
  ${doneToday && !PROG.daily.solved ? `<div class="notice">${esc(t('dailyUsed'))}</div>` : ''}
  ${cardGrid([d])}
  <p class="small dim">${esc(t('dailyMystery'))}: ${esc(diffLabel(d))} · ${esc(lenLabel(d))} · ${esc(catName(d.category))} · +100 ${esc(t('xp'))} ${esc(t('streak'))}.</p>`;
}
/* daily attempt bookkeeping: count a failed deduction against today's attempts */
function dailyAttempt() {
  const d = dailyCase();
  if (PROG.daily.date !== today()) {
    PROG.daily.date = today();
    PROG.daily.id = d.id;
    PROG.daily.attempts = 0;
    PROG.daily.solved = false;
  }
  PROG.daily.attempts += 1;
  if (PROG.daily.attempts >= 3 && !PROG.daily.solved) PROG.daily.streak = 0;
  saveProg();
}

/* ---------- multiplayer (local prototype) ---------- */
function createRoom() {
  state.room = Math.random().toString(36).slice(2, 8).toUpperCase();
  state.role = Math.random() < 0.34 ? 'criminal' : 'detective';
  render();
}
function joinRoom() { state.room = 'DEMO01'; state.role = 'detective'; render(); }
function leaveRoom() { state.room = null; state.role = null; render(); }
function vote(name) { toast('🗳 ' + t('vote') + ': ' + name + ' — ' + t('onlineNote')); }
function multiScreen() {
  const roleLabel = state.role === 'criminal' ? t('criminal') : t('detective');
  return `
  <h1>🎭 ${esc(t('multiplayer'))}</h1>
  <section class="hero">
    <span class="eyebrow">${esc(t('multiplayer'))}</span>
    <h2>5 ${esc(t('players'))} + 1 ${esc(t('criminal'))}</h2>
    <p class="muted">${esc(t('howTo2'))}</p>
    ${state.room ? '' : `<div class="btn-row">
      <button class="btn" onclick="createRoom()">${esc(t('createRoom'))}</button>
      <button class="btn secondary" onclick="joinRoom()">${esc(t('joinRoom'))}</button>
    </div>`}
  </section>
  ${state.room ? `
    <div class="panel-card">
      <div class="meta-row"><span class="tag">${esc(t('roomCode'))}: <b>${esc(state.room)}</b></span>
        <span class="tag pro">${esc(t('players'))}: 1/6</span></div>
      <div class="lock-note" style="margin-top:12px">🎭 ${esc(t('roleReveal'))}: <b>${esc(roleLabel)}</b></div>
      <p class="small dim" style="margin-top:10px">${esc(t('onlineNote'))}</p>
      <div class="sep"></div>
      <p class="small dim">${esc(t('vote'))}:</p>
      <div class="btn-row">
        ${['Alex', 'Morgan', 'Taylor', 'Jordan'].map(n => `<button class="btn ghost" onclick="vote('${n}')">${esc(n)}</button>`).join('')}
      </div>
      <div class="btn-row"><button class="btn secondary" onclick="leaveRoom()">← ${esc(t('back'))}</button></div>
    </div>` : ''}
  <h2>🎭 ${esc(t('mpLibrary'))} <span class="count">${MP_CASES.length}</span></h2>
  <p class="muted small">${esc(t('mpLibrarySub'))} ${esc(t('mpShareNote'))}</p>
  <div class="grid">${MP_CASES.map(mpCard).join('')}</div>
  <div class="notice">${esc(t('multiplayerComing'))}</div>`;
}
/* Multiplayer campaign card — four private clues instead of a suspect list. */
function mpCard(c) {
  const locked = isLocked(c);
  const done = !!PROG.solved[c.id];
  return `<article class="card ${c.premium ? 'premium' : ''}">
    <div class="meta-row">
      <span class="tag diff">${dots(c.difficulty)} ${esc(diffLabel(c))}</span>
      <span class="tag">🎭 ${MP_PLAYERS.length} ${esc(t('players'))}</span>
      ${c.premium ? `<span class="tag pro">${esc(t('premiumBadge'))}</span>` : `<span class="tag free">${esc(t('freeCase'))}</span>`}
      ${done ? `<span class="tag free">✓ ${esc(t('solved'))}</span>` : ''}
    </div>
    <h3>${esc(c.title)}</h3>
    <p class="meta">${esc(catName(c.category))} · ${esc(c.time)} · ${c.xp} ${esc(t('xp'))}</p>
    <p>${esc(c.summary)}</p>
    <p class="meta">${MP_PLAYERS.length} ${esc(t('mpClues').toLowerCase())} · ${c.evidence} ${esc(t('evidence').toLowerCase())}</p>
    <button class="btn ${locked ? 'pro' : done ? 'secondary' : ''}" onclick="openCase('${c.id}')">
      ${locked ? esc(t('unlock')) : done ? esc(t('seeSolution')) : esc(t('play'))}
    </button>
  </article>`;
}

/* ---------- store / paywall ($5.99) ---------- */
function storeScreen() {
  const pro = STORE.isPremium();
  return `
  <h1>🛍️ ${esc(t('store'))}</h1>
  <div class="brand-line"><img src="brand/logo-96.png" alt="" width="96" height="96"><b>${esc(t('sloganHome'))}</b></div>
  <div class="plans">
    <div class="plan best">
      <span class="tag pro">${esc(t('premiumBadge'))}</span>
      <h2 style="margin:10px 0 4px">${esc(t('premiumTitle'))}</h2>
      <p class="muted" style="margin:0">${esc(t('premiumSub'))}</p>
      <div class="price" style="margin-top:12px">${esc(I18N.PRICE)}<small>${esc(t('perMonth'))}</small></div>
      <p class="small dim">${esc(t('priceNote'))}</p>
      <ul>
        <li>${esc(t('f1'))}</li><li>${esc(t('f2'))}</li><li>${esc(t('f3'))}</li>
        <li>${esc(t('f4'))}</li><li>${esc(t('f5'))}</li><li>${esc(t('f6'))}</li>
      </ul>
      ${pro
        ? `<div class="notice">✓ ${esc(t('subscribed'))}<br><span class="small">${esc(t('subscribedMsg'))}</span></div>`
        : `<button class="btn pro block" onclick="buy('premium_monthly')">★ ${esc(t('subscribe'))} — ${esc(I18N.PRICE)}${esc(t('perMonth'))}</button>`}
      <div class="btn-row">
        <button class="btn secondary" onclick="restorePurchases()">↺ ${esc(t('restorePurchases'))}</button>
      </div>
    </div>
    <div>
      ${packCard('pack_starter')}
      ${packCard('pack_detective')}
      ${packCard('hints_10')}
    </div>
  </div>
  <div class="notice">${esc(t('checkoutBody'))}</div>`;
}
function packCard(id) {
  const p = STORE.product(id);
  const owned = p.kind === 'non_consumable' && STORE.ownsPack(id);
  const title = id === 'pack_starter' ? t('pack_starter') : id === 'pack_detective' ? t('pack_detective') : id === 'hints_10' ? t('hints') + ' ×10' : p.title;
  const detail = id === 'pack_starter' ? '5 ' + t('casesAvailable') : id === 'pack_detective' ? '10 ' + t('casesAvailable') : id === 'hints_10' ? t('pack_hints') : (p.detail || '');
  return `<div class="pack" style="margin-top:12px">
    <span class="tag">${esc(p.kind === 'subscription' ? t('premiumBadge') : t('store'))}</span>
    <h3 style="margin:8px 0 0">${esc(title)}</h3>
    <div class="p">${esc(p.price)}${p.per ? '<span class="small dim">/' + esc(p.per) + '</span>' : ''}</div>
    <p class="muted small">${esc(detail)}</p>
    <button class="btn ${owned ? 'secondary' : 'pro'}" ${owned ? 'disabled' : ''} onclick="buy('${id}')">
      ${owned ? '✓ ' + esc(t('subscribed')) : esc(t('subscribe'))}
    </button>
  </div>`;
}
async function buy(id) {
  const p = STORE.product(id);
  if (!p) return;
  if (id === 'premium_monthly' && STORE.isPremium()) { toast(t('premiumOwned')); return; }
  /* sandbox confirmation sheet (native builds show the store sheet instead) */
  document.getElementById('modal').classList.add('open');
  document.getElementById('panel').innerHTML = `
    <button class="close" onclick="closeModal()">✕</button>
    <div class="eyebrow">${esc(t('checkoutTitle'))}</div>
    <h2 style="margin-top:8px">${esc(p.title)}</h2>
    <div class="price" style="font-size:34px;font-weight:900">${esc(p.price)}${p.per ? '<span class="small dim"> ' + esc(t('perMonth')) + '</span>' : ''}</div>
    <p class="muted">${esc(t('checkoutBody'))}</p>
    <div class="btn-row">
      <button class="btn pro" id="confirm-buy">${esc(t('checkoutConfirm'))}</button>
      <button class="btn secondary" onclick="closeModal()">${esc(t('maybeLater'))}</button>
    </div>`;
  document.getElementById('confirm-buy').onclick = async () => {
    const res = await STORE.purchase(id);
    closeModal();
    if (res.ok) {
      AUDIO.play('buy');
      toast(id === 'premium_monthly' ? t('subscribedMsg') : t('restoreOk'));
      checkAchievements();
    } else {
      toast(t('connectionNeeded') + ' (' + res.error + ')');
    }
    render();
  };
}
async function restorePurchases() {
  const res = await STORE.restore();
  if (res.ok && res.count > 0) toast(t('restoreOk'));
  else if (res.ok) toast(t('restoreNone'));
  else toast(t('connectionNeeded'));
  render();
}

/* ---------- archive ---------- */
function archiveScreen() {
  const all = allCases();
  const solved = all.filter(c => PROG.solved[c.id]);
  const inProgress = all.filter(c => PROG.opened[c.id] && !PROG.solved[c.id]);
  const locked = all.filter(c => isLocked(c));
  const unsolved = all.length - solved.length - inProgress.length;
  return `
  <h1>🗃️ ${esc(t('archive'))}</h1>
  <div class="stats-grid">
    <div class="stat"><b>${solved.length}</b><span>🟢 ${esc(t('solved'))}</span></div>
    <div class="stat"><b>${inProgress.length}</b><span>🟡 ${esc(t('continueCase'))}</span></div>
    <div class="stat"><b>${unsolved}</b><span>🔴 ${esc(t('unsolved'))}</span></div>
    <div class="stat"><b>${locked.length}</b><span>🔒 ${esc(t('premiumBadge'))}</span></div>
  </div>
  <h2>✅ ${esc(t('solved'))}</h2>
  ${solved.length ? cardGrid(solved) : `<div class="notice">${esc(t('notSolvedYet'))}</div>`}
  ${inProgress.length ? `<h2>🟡 ${esc(t('continueCase'))}</h2>${cardGrid(inProgress)}` : ''}
  ${locked.length ? `<h2>🔒 ${esc(t('premiumCasesLockedShort'))}</h2>${cardGrid(locked)}` : ''}
  <h2>🏆 ${esc(t('achievements'))}</h2>
  <div class="ach-grid">
    ${ACH.map(a => `<div class="ach ${PROG.ach[a.id] ? 'unlocked' : ''}"><b>${PROG.ach[a.id] ? '🏆 ' : '🔒 '}${esc(ACH_NAMES[a.id])}</b>${PROG.ach[a.id] ? '✓ ' + esc(t('progress')) : esc(t('notSolvedYet'))}</div>`).join('')}
  </div>`;
}

/* ---------- settings ---------- */
function settingsScreen() {
  return `
  <h1>⚙️ ${esc(t('settings'))}</h1>
  <div class="panel-card">
    <div class="eyebrow">${esc(t('language'))}</div>
    <p class="muted small">${esc(t('chooseLanguage'))} — ${I18N.all().length} ${esc(t('f2'))}</p>
    <div class="lang-grid">
      ${I18N.all().map(m => `
        <button class="lang-btn ${I18N.lang() === m.code ? 'active' : ''}" onclick="setLang('${m.code}')">
          <span>${m.flag}</span> ${esc(m.name)}
        </button>`).join('')}
    </div>
  </div>
  <div class="row"><span class="k">🎵 ${esc(t('music'))}</span>
    <button class="btn secondary" onclick="toggleMusic()">${AUDIO.musicEnabled() ? '🔊 ' + esc(t('on')) : '🔇 ' + esc(t('off'))}</button>
  </div>
  <div class="row"><span class="k">🔉 ${esc(t('sfx'))}</span>
    <button class="btn secondary" onclick="toggleSfx()">${AUDIO.sfxEnabled() ? '🔊 ' + esc(t('on')) : '🔇 ' + esc(t('off'))}</button>
  </div>
  <div class="row"><span class="k">★ ${esc(t('navPremium'))}</span>
    <span class="v">${STORE.isPremium() ? '✓ ' + esc(t('subscribed')) : esc(I18N.PRICE) + esc(t('perMonth'))}</span>
    <button class="btn ${STORE.isPremium() ? 'secondary' : 'pro'}" onclick="go('store')">${STORE.isPremium() ? esc(t('subscribed')) : esc(t('goPremium'))}</button>
  </div>
  <div class="row"><span class="k">📱 ${esc(t('offlineNote'))}</span><span class="v">v1.0.0</span></div>
  <div class="row"><span class="k">${esc(t('stats'))}</span>
    <span class="v">${esc(t('level'))} ${level()} · ${PROG.xp} ${esc(t('xp'))} · ${solvedCount()}/${allCases().length} ${esc(t('casesSolved'))}</span>
  </div>
  <div class="row"><span class="k">${esc(t('multiplayer'))}</span><span class="v small">${esc(t('multiplayerComing'))}</span></div>
  <div class="btn-row">
    <button class="btn secondary" onclick="restorePurchases()">↺ ${esc(t('restorePurchases'))}</button>
    <button class="btn ghost" onclick="resetProgress()">🗑 ${esc(t('resetProgress'))}</button>
  </div>`;
}
function toggleMusic() { AUDIO.toggleMusic(); AUDIO.play('click'); render(); }
function toggleSfx() { const wasOn = AUDIO.sfxEnabled(); AUDIO.toggleSfx(); if (wasOn) { /* last click */ } render(); }
function setLang(code) {
  I18N.set(code);
  render();
  toast(t('langChanged'));
}
function resetProgress() {
  if (!confirm(t('resetConfirm'))) return;
  PROG = JSON.parse(JSON.stringify(PROG_DEFAULT));
  saveProg();
  render();
  toast(t('resetDone'));
}

/* ---------- achievements ---------- */
const ACH = [
  { id: 'first', test: p => Object.keys(p.solved).length >= 1 },
  { id: 'sharp', test: p => Object.keys(p.seen).reduce((n, k) => n + p.seen[k].length, 0) >= 10 },
  { id: 'nohints', test: p => Object.keys(p.solved).some(k => p.solved[k].hints === 0) },
  { id: 'perfect', test: p => Object.keys(p.solved).some(k => p.solved[k].perfect) },
  { id: 'ten', test: p => Object.keys(p.solved).length >= 10 },
  { id: 'fifty', test: p => Object.keys(p.solved).length >= 50 },
  { id: 'marathon', test: p => p.daily.streak >= 3 },
  { id: 'master', test: p => Object.keys(p.solved).some(k => { const c = findCase(k); return c && (c.difficulty === 'Expert' || c.difficulty === 'Extreme'); }) },
  { id: 'detective', test: p => Math.floor(p.xp / 500) + 1 >= 5 }
];
function checkAchievements() {
  ACH.forEach(a => {
    if (!PROG.ach[a.id] && a.test(PROG)) {
      PROG.ach[a.id] = true;
      AUDIO.play('achievement');
      toast('🏆 ' + (ACH_NAMES[a.id] || a.id));
    }
  });
  saveProg();
}
const ACH_NAMES = {
  first: 'First Case', sharp: 'Sharp Eye', nohints: 'No Hints', perfect: 'Perfect Deduction',
  ten: '10 Cases Solved', fifty: '50 Cases Solved', marathon: 'Mystery Marathon',
  master: 'Case Master', detective: 'Master Detective'
};

/* ---------- boot ---------- */
(function bootFromHash() {
  const h = (location.hash || '').replace('#', '');
  const valid = ['home', 'cases', 'daily', 'multi', 'store', 'archive', 'settings'];
  if (h && valid.indexOf(h) !== -1) state.screen = h;
})();
render();
splash(mysteryLine());   /* brand guide: rotating mystery line on the loading screen */
if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
  navigator.serviceWorker.register('sw.js').catch(() => { /* offline unavailable */ });
}
