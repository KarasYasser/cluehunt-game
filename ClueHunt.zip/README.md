# ClueHunt — Digital Investigation Room

A mobile-first mystery game that runs as an **installable app on Android and iOS** (PWA)
and can be wrapped as a native store build (Capacitor).

## What's inside

- **66 cases** across 10 categories (Fictional, True Stories, Historical, Unsolved,
  Missing Objects, Impossible Rooms, Hidden Identity, Cyber, Treasure Hunts, Logic)
  × Easy / Medium / Hard / Expert × Short / Long, each with evidence, suspects,
  hints, deduction scoring, XP and a full solution.
- **50 free cases** — every Easy + Medium, **5 Hard** (Tower of Six Locks, Clockmaker's
  Confession, D.B. Cooper, Ninth Legion Vanishes, Unexplained Signal) and **5 Expert**
  (Vault Beneath Bellamy Hall, Airgap Heist, Meridian Vault, Crown Impostor, Ninth Page).
  The remaining 16 Hard/Expert cases unlock with **Premium — $5.99/month**.
- **12 languages** with RTL support: English, Español, Français, Deutsch, Português,
  Italiano, Русский, العربية, हिन्दी, 中文, 日本語, Türkçe.
- **Mystery music + per-stage sound effects** (all synthesized — no audio files),
  each toggleable in Settings.
- Daily Mystery with streak, XP/levels, 9 achievements, Archive stats,
  Multiplayer prototype (rooms/roles/voting), Store (Premium $5.99, case packs,
  hint tokens), Settings with language picker and toggles.
- Offline-capable: service worker caches the whole app shell.

## Run it

Open `index.html` via any static server, e.g.:

```
python -m http.server 8080
# then visit http://localhost:8080
```

## Publish it (2 minutes, free)

The app is 100% static — publish by uploading this folder:

1. **Netlify Drop** — go to <https://app.netlify.com/drop>, drag this folder in, done.
2. **GitHub Pages** — push this folder to a repo → Settings → Pages → deploy from branch.
3. **Vercel** — `npx vercel` inside this folder.

Once hosted over HTTPS, users open the link and **"Add to Home Screen"**
(Chrome on Android shows **Install app**; Safari on iOS: Share → Add to Home Screen)
— it installs like a native app with the icon, splash and offline mode.

## Native Android / iOS store builds (Capacitor)

```
npm init -y
npm i @capacitor/core @capacitor/cli @capacitor/android @capacitor/ios
npx cap init ClueHunt com.cluehunt.app --web-dir www
# copy this folder's files into www/  (index.html, styles.css, *.js, js/, icons/, manifest.json)
npx cap add android && npx cap sync     # then: npx cap open android  (Android Studio, JDK 17)
npx cap add ios && npx cap sync         # then: npx cap open ios      (macOS + Xcode)
```

### Store products

| Product id        | Price     | Type           |
|-------------------|-----------|----------------|
| `premium_monthly` | **$5.99** | subscription   |
| `pack_starter`    | $1.99     | non-consumable |
| `pack_detective`  | $3.99     | non-consumable |
| `hints_10`        | $0.99     | consumable     |

Create these in **Play Console** (subscriptions/products) and **App Store Connect**
(auto-renewable subscription + in-app purchases), then implement the native bridge
`window.ClueHuntIAP.purchase(id)` / `.restore()` (see `store.js`) using
Google Play Billing / StoreKit (or RevenueCat). Without the bridge the app falls back
to the built-in sandbox checkout — no real charge.

## Structure

```
index.html      app shell        styles.css   design system
app.js          screens/logic    data.js      66-case library
store.js        purchase adapter (Premium $5.99)
audio.js        music + SFX      js/i18n.js   12 languages
sw.js, manifest.json, icons/     PWA install layer
```
